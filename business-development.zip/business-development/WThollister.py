import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

def scrape_hollister():

    #url for all jobs
    url = 'https://jobs.hollister.com/search/?createNewAlert=false&q=&locationsearch=&optionsFacetsDD_department=Information+Technology&optionsFacetsDD_country='

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    }
    r = requests.get(url, headers=headers)
    soup = BeautifulSoup(r.content, 'html.parser')

    jobs_list = []  # List to store all job postings

    tables = soup.find_all('table')
    for table in tables:
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')
        for row in rows:
            job_data = {}
            cells = row.find_all('td')
            link = cells[0].find('a')
            if link:
                job_title = link.get_text(strip=True)
        
                job_link = urljoin('https://jobs.hollister.com/', link['href'])
            location = cells[0].find('span', class_ = 'jobLocation').get_text(strip = True)
            
            job_data['Company'] = 'Hollister'
            job_data['Job Title'] = job_title
            job_data['Job Link'] = job_link
            job_data['Location'] = location
            job_data['Date Posted'] = None
            job_data['ID'] = None
            job_data['Category'] = None
            job_data['Job Type'] = None


            jobs_list.append(job_data)


            
        

    print('scraping Hollister')



    return jobs_list
