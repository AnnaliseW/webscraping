from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager


def scrape_allstate():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://www.allstate.jobs/job-search-results/?category[]=Data%20Science%20%26%20Analytics&category[]=Information%20Technology')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.CSS_SELECTOR, "div.job.clearfix")

    jobs_list = []

    for job in jobs:
        job_info = {}
        
        title_element = job.find_element(By.CSS_SELECTOR, "div.jobTitle")
        title = title_element.text

        a_element = job.find_element(By.CSS_SELECTOR, "div.jobTitle a")
        job_link = a_element.get_attribute("href")

        category_element = job.find_element(By.CSS_SELECTOR, "div.flex_column.av_one_sixth")
        category = category_element.text

        location_element = job.find_element(By.CSS_SELECTOR, 'div.flex_column.joblist-location.av_one_sixth')
        location = location_element.text

        jobLevel_element = job.find_element(By.CSS_SELECTOR, 'div.flex_column.av_one_seventh')
        jobLevel = jobLevel_element.text

        date_element = job.find_element(By.CSS_SELECTOR, 'div.flex_column.joblist-posdate.av_one_seventh')
        date = date_element.text


        job_info = {
            'Company': 'Allstate',
            'Job Title': title,
            'Job Link': job_link,
            'Location': location,
            'Date Posted': date,
            'ID': None,
            'Category': category,
            'Job Type': jobLevel
        }

        jobs_list.append(job_info)

   
    print('scraping All State')
    # Close the browser
    driver.quit()

    return jobs_list
