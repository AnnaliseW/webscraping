from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_nielsen():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://jobs.lever.co/nielsen?department=Technology')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    jobs_list = []

    job_listings = driver.find_elements(By.CSS_SELECTOR, 'div.postings-group')



    for job in job_listings:

        category = job.find_element(By.CSS_SELECTOR, 'div.posting-category-title.large-category-label').text
        if not category:
            category = job.find_element(By.CSS_SELECTOR, 'div.large-category-header').text
        
        

        postings = job.find_elements(By.CSS_SELECTOR, 'div.posting')
        for post in postings:
            job_info = {}
            title = post.find_element(By.TAG_NAME, 'h5').text
        
            link = post.find_element(By.CSS_SELECTOR, 'a.posting-title').get_attribute('href')
            

            test = post.find_element(By.CSS_SELECTOR, 'div.posting-categories').text
            

            if 'FULL' in test:
                dash = test.split('—')
                jobType = dash[0] + ',' + ' FULL'
            
                location = dash[1].replace('FULL', '').strip()
                
            else:
                dash = test.split('—')
                jobType = dash[0]
                location = dash[1]
            



            
            job_info['Company'] = 'Nielsen'
            job_info['Job Title'] = title
            job_info['Job Link'] = link
            job_info['Location'] = location
            job_info['Date Posted'] = None
            job_info['ID'] = None
            job_info['Category'] = category
            job_info['Job Type'] = jobType

        
            jobs_list.append(job_info)

        



    print('scraping nielsen')
    



    # Close the browser
    driver.quit()
    return jobs_list

