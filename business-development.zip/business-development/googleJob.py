from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# Setup chrome options
chrome_options = Options()
chrome_options.add_argument("--headless")  # Ensure GUI is off
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")

# Set up the Chrome webdriver service
webdriver_service = Service(ChromeDriverManager().install())

# Start the browser
driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

# List to store job details
job_list = []


    # Open the webpage
driver.get('https://www.google.com/search?q=devops+jobs+illinois+linkedin&ibp=htl;jobs&sa=X&ved=2ahUKEwiGvOyFz7WGAxUehIkEHQZvBw8QutcGKAF6BAgTEAQ&sxsrf=ADLYWIKTduaFdTReKYPlnRjRboxz-QKYuA:1717080424133#htivrt=jobs&htidocid=XVL-eHaBc7cDhaAAAAAAAA%3D%3D&fpstate=tldetail')



   
    

driver.quit()
