from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin

def scrape_HCSC():

    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://hcsc.wd1.myworkdayjobs.com/HCSC_External?jobFamilyGroup=bc8a97f6c8a5100e639f37d66baa0001&jobFamilyGroup=bc8a97f6c8a5100e639f421343c70002')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.CSS_SELECTOR, "li.css-1q2dra3")


    jobs_list = []

    for job in jobs:
        job_info = {}
        title = job.find_element(By.CSS_SELECTOR, 'a.css-19uc56f')
        link = title.get_attribute('href')
        title = title.text
        

        location = job.find_element(By.CSS_SELECTOR, 'dd.css-129m7dg').text


        date = job.find_element(By.XPATH, ".//dt[text()='posted on']/following-sibling::dd").text
        

        id = job.find_element(By.CSS_SELECTOR, 'li.css-h2nt8k').text
        
        job_info['Company'] = 'HCSC'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = id
        job_info['Category'] = None
        job_info['Job Type'] = None

        jobs_list.append(job_info)





    print('scraping HCSC')
    
    driver.quit()
    return jobs_list
