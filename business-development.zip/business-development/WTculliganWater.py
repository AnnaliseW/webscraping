from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_culliganWater():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://recruiting2.ultipro.com/DWF1000/JobBoard/c9da00d5-d0c1-442d-9461-aeea58d18b70/?q=&o=postedDateDesc&w=&wc=&we=&wpst=&f5=Ci_B7U__tEeeKaf1gT253Q')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    # Get the dynamic content
    job_listings = driver.find_elements(By.CLASS_NAME, 'opportunity')


    jobs_list = []

    for job in job_listings:
        job_info = {}
        
        title_element = job.find_element(By.CLASS_NAME, 'opportunity-link')
        
        title = title_element.text

        
        # Extract the job link
        link = title_element.get_attribute('href')


        date = job.find_element(By.TAG_NAME, 'small')
        date = date.text


        job_category_element = job.find_element(By.CSS_SELECTOR, '.label-with-icon [data-bind="text: JobCategoryName()"]')
        
        # Extract the job category text
        category = job_category_element.text
        

        reqID = job.find_element(By.CSS_SELECTOR, '.label-with-icon [data-bind="text: RequisitionNumber()"]')
        # Extract the requisition number text
        reqID = reqID.text
        

        jobType = job.find_element(By.CSS_SELECTOR, '.label-with-icon [data-bind="text: FullTimeText"]')
        jobType = jobType.text


        location = job.find_element(By.CSS_SELECTOR, 'div.location-bottom')
        location = location.text
        if '\n' in location:
            split = location.split('\n')
            location = split[3]

        

        job_info = {
                    'Company': 'Culligan Water',
                    'Job Title': title,
                    'Job Link': link,
                    'Location': location,
                    'Date Posted': date,
                    'ID': reqID,
                    'Category': category,
                    'Job Type' : jobType,
                }
                
        jobs_list.append(job_info)

        for job in jobs_list:
            print(job)
            

    print('scraping culligan water')

    driver.quit()
    return jobs_list








        






