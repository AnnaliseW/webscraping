import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin


def scrape_sheddAquarium():
    url = 'https://sheddaquarium.applicantstack.com/x/openings'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    }
    r = requests.get(url, headers=headers)
    soup = BeautifulSoup(r.content, 'html.parser')

    jobs_list = []  # List to store all job postings

    tables = soup.find_all('table')
    for table in tables:
        job_info = {}
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')
        for row in rows:
            job_data = {}
            cells = row.find_all('td')
        
            title = cells[0].find('a').get_text(strip=True)
            department = cells[1].get_text(strip=True)
            
            
            
            
            jobLink = cells[0].find('a')
            jobLink = jobLink['href']
            
                
            job_info = {
                'Company': 'Shedd Aquarium',
                'Job Title': title,
                'Job Link': jobLink,
                'Location': None,
                'Date Posted': None,
                'ID': None,
                'Category': department,
                'Job Type': None
            }
            
            jobs_list.append(job_info)

    print('scraping Shedd Aquarium')
    

    return jobs_list
