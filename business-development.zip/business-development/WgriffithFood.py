from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin

def scrape_griffithFood():

    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://globalus241.dayforcehcm.com/CandidatePortal/en-US/griffith/')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.CSS_SELECTOR, "li.search-result")


    jobs_list = []

    for job in jobs:
        job_info = {}
        title = job.find_element(By.CSS_SELECTOR, 'div.posting-title')
        title = title.text
        

        link = job.find_element(By.CSS_SELECTOR, 'div.posting-title a')
        link = link.get_attribute('href')
        

        locationAndId = job.find_element(By.CSS_SELECTOR, 'div.posting-subtitle').text

        split = locationAndId.split('\u25cf')
        location = split[0]
        id = split[1]
    

        date = job.find_element(By.CSS_SELECTOR, 'div.posting-date').text
        
        job_info['Company'] = 'Griffith Food'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = id
        job_info['Category'] = None
        job_info['Job Type'] = None

        jobs_list.append(job_info)

    print('scraping Griffith Food')
    driver.quit()
    return jobs_list
