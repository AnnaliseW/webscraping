import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

def scrape_grainger():


    #url for only tech jobs
    urlTechJobs = 'https://jobs.grainger.com/go/Information-technology/2432200/'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    }
    r = requests.get(urlTechJobs, headers=headers)
    soup = BeautifulSoup(r.content, 'html.parser')

    jobs_list = []  # List to store all job postings

    tables = soup.find_all('table')
    for table in tables:
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            job_info = {}
            jobLocation = cells[0].find(class_='jobLocation')
            if jobLocation:
                jobLocation = jobLocation.get_text(strip=True)
            else:
                jobLocation = "N/A"  
            
            jobDate = cells[0].find(class_='jobDate')
            if jobDate:
                jobDate = jobDate.get_text(strip=True)
            else:
                jobDate = "N/A" 
            
            jobLink = cells[0].find('a', class_='jobTitle-link')
            
            if jobLink:
                job_title = jobLink.get_text(strip=True)
                job_link = urljoin(urlTechJobs, jobLink['href'])
                position_title = job_link.split('/')[-2]
                
                
                job_info = {
                    'Company': 'Grainger',
                    'Job Title': job_title,
                    'Job Link': job_link,
                    'Location': jobLocation,
                    'Date Posted': jobDate,
                    'ID': None,
                    'Category': None,
                    'Job Type': position_title
                }
                
                jobs_list.append(job_info)

    print('scraping Grainger')
    return jobs_list
