from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager


def scrape_reyesHolding():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://jobs.reyesholdings.com/ims-en/job-search-results/?category=Information%20Technology%20and%20Technical%20Support')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.XPATH, '//*[@id="widget-jobsearch-results-list"]/div')


    jobs_list = []

    for job in jobs:
        job_info = {}
        title = job.find_element(By.CSS_SELECTOR, 'div.jobTitle')
        title = title.text
        

        link = job.find_element(By.TAG_NAME, 'a')
        link = link.get_attribute('href')
        

        category = job.find_element(By.CSS_SELECTOR, 'div.flex_column.fusion-layout-column.fusion-one-fourth')
        category = category.text
    

        location = job.find_element(By.CSS_SELECTOR, 'div.flex_column.joblist-location.av_one_fourth')
        location = location.text
        

        job_info = {
            'Company': 'Reyes Holding',
            'Job Title': title,
            'Job Link': link,
            'Location': location,
            'Date Posted': None,
            'ID': None,
            'Category': None,
            'Job Type': None
        }

        jobs_list.append(job_info)

        
        
    print('scraping Reyes Holding')
    




    # Close the browser
    driver.quit()

    return jobs_list