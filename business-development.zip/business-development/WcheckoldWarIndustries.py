from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_oldWarIndustries():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://workforcenow.adp.com/mascsr/default/mdf/recruitment/recruitment.html?cid=4ee6cf69-a7b8-4505-906d-f0077f07c536&ccId=19000101_000001&type=MP&lang=en_US&selectedMenuKey=CurrentOpenings')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found


    
    # Get the dynamic content
    job_listings = driver.find_elements(By.CLASS_NAME, 'current-openings-item')


    jobs_list = []


    for job in job_listings:
        job_info = {}

        title = job.find_element(By.CLASS_NAME, 'current-opening-title').text
    

        location = job.find_element(By.CSS_SELECTOR, 'label.current-opening-location-item').text
        

        date = job.find_element(By.CSS_SELECTOR, 'span.current-opening-post-date').text
        

    # DOES NOT CURRENTLY HAVE LINK
        job_info['Company'] = 'Old War Industries'
        job_info['Job Title'] = title
        job_info['Job Link'] = None
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = None
        job_info['Category'] = None
        job_info['Job Type'] = None


        jobs_list.append(job_info)

    print('scraping old war industries')

        



        



    # Close the browser
    driver.quit()
    return jobs_list
