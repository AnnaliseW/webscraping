from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.common.exceptions import NoSuchElementException


def scrape_follete():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GU I is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://recruiting.adp.com/srccar/public/RTI.home?c=1122441&d=Corporate_External')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found


    # Get the dynamic content
    job_listings = driver.find_elements(By.CSS_SELECTOR, 'div.slidedown')




    jobs_list = []


    for job in job_listings:
        job_info = {}

        title = job.find_element(By.TAG_NAME, 'a').text
        

        id = job.find_element(By.CSS_SELECTOR, 'span.jobnum').text
        

        try:
            location_element = job.find_element(By.CSS_SELECTOR, 'span.resultfootervalue')
            location = location_element.text 
        except NoSuchElementException:
            #no location was found
            location = None



        category_element = job.find_elements(By.CSS_SELECTOR, 'li.col-sm-4.col-resize3')
        if len(category_element) == 2:
            category = category_element[0].text
        else:
            category = category_element[1].text

        if category == 'Information Technology':

            job_info['Company'] = 'Follete'
            job_info['Job Title'] = title
            job_info['Job Link'] = None
            job_info['Location'] = location
            job_info['Date Posted'] = None
            job_info['ID'] = id
            job_info['Category'] = category
            job_info['Job Type'] = None

            
            jobs_list.append(job_info)
            




    print('scraping Follete')
        

    # Close the browser
    driver.quit()
    return jobs_list