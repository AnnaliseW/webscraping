from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def scrape_univar():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://careers.univarsolutions.com/search/?createNewAlert=false&q=&locationsearch=&optionsFacetsDD_dept=&optionsFacetsDD_title=&optionsFacetsDD_country=&optionsFacetsDD_city=&optionsFacetsDD_state=&optionsFacetsDD_zip=')
    wait = WebDriverWait(driver, 10)
    jobs_list = []
    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    wait = WebDriverWait(driver, 10)

    jobs = driver.find_elements(By.XPATH, '//*[@id="job-tile-list"]/li')



    for job in jobs:
        job_info = {}
        elements = job.find_elements(By.TAG_NAME, 'div')
        
        title = elements[1].text
        title = title.replace('Title', '')

        job_title_element = job.find_element(By.CSS_SELECTOR, '[class^=jobTitle-link]')
        link = job_title_element.get_attribute('href')
        

        split = title.split('\n')
        
        title = split[1]
        

        location = split[3]
        
        category = split[5]
    

        date = split[7]

        job_info['Company'] = 'Univar'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = None
        job_info['Category'] = category
        job_info['Job Type'] = None

            

        jobs_list.append(job_info)
        
    print('scraping univar')
    
    driver.quit()
    return jobs_list

