from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def scrape_transformHolding():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://sjobs.brassring.com/TGnewUI/Search/Home/Home?partnerid=455&siteid=185#home')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found


    # Get the dynamic content
    job_listings = driver.find_elements(By.CSS_SELECTOR, 'div.liner.lightBorder')





    jobs_list = []


    for job in job_listings:
        job_info = {}

        title = job.find_element(By.TAG_NAME, 'a').text
        

        link = job.find_element(By.TAG_NAME, 'a').get_attribute('href')
        

        date = job.find_element(By.CSS_SELECTOR, 'p.jobProperty.position1').text
        

        

        job_info['Company'] = 'Transform Holding'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = None
        job_info['Date Posted'] = date
        job_info['ID'] = None
        job_info['Category'] = None
        job_info['Job Type'] = None


        jobs_list.append(job_info)




    print('scraping Transform Holding/Transform Co')

        

    # Close the browser
    driver.quit()
    return jobs_list
