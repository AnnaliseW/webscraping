from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_hugoBoss():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://careers.hugoboss.com/global/en/search-results?keywords=')
    wait = WebDriverWait(driver, 10)

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found
    jobs_list = []
    job_elements = driver.find_elements(By.CLASS_NAME, 'jobs-list-item')

    for job in job_elements:
        job_info = {}
        title = job.find_element(By.CLASS_NAME, 'job-title').text
        

        link = job.find_element(By.TAG_NAME, 'a').get_attribute('href')
        

        elements = job.find_elements(By.CSS_SELECTOR, 'span.au-target')
        
        
        location = elements[6].text
        location = location + ', ' + elements[5].text
        

        category = elements[8].text
        category = category.replace('Category', '')
        category = category.replace('\n', '')



        jobType = elements[9].text

        job_info['Company'] = 'Hugo Boss'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = None
        job_info['ID'] = None
        job_info['Category'] = category
        job_info['Job Type'] = jobType

        jobs_list.append(job_info)
        

    techJobs = []
    

    print('scraping Hugo Boss')



    # Close the browser
    driver.quit()
    return jobs_list

