from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# Setup chrome options
chrome_options = Options()
chrome_options.add_argument("--headless")  # Ensure GUI is off
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")

# Set up the Chrome webdriver service
webdriver_service = Service(ChromeDriverManager().install())

# Start the browser
driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

# List to store job details
job_list = []

try:
    # Open the webpage
    driver.get('https://www.indeed.com/jobs?q=developer&l=Chicago%2C+IL&from=searchOnHP&vjk=ad0c5eed9519fbd9')

    # Wait for the job results container to be present
    job_page = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "mosaic-provider-jobcards")))

    # Find job elements within the container
    jobs = job_page.find_elements(By.CLASS_NAME, "job_seen_beacon")

    for job in jobs:
        job_title = job.find_element(By.CLASS_NAME, "jobTitle")
        job_list.append({
            'title': job_title.text,
            'link': job_title.find_element(By.CSS_SELECTOR, "a").get_attribute("href"),
            'job_id': job_title.find_element(By.CSS_SELECTOR, "a").get_attribute("id"),
            'company': job.find_element(By.CLASS_NAME, "companyName").text,
            'location': job.find_element(By.CLASS_NAME, "companyLocation").text,
            'date': job.find_element(By.CLASS_NAME, "date").text,
        })
    
    # Print job list
    for job in job_list:
        print(job)

except TimeoutException:
    print("Timeout occurred while waiting for the job page to load.")

finally:
    # Quit the driver
    driver.quit()
