from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_anixter():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://eklm.fa.us2.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX/requisitions?lastSelectedFacet=CATEGORIES&selectedCategoriesFacet=300000034786562')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    # Get the dynamic content
    job_listings = driver.find_elements(By.XPATH, '/html/body/div[3]/div[1]/div/div[1]/main/div/div/div/div/div/div[3]/div/div/div/div[1]/div/div/ul/li')



    jobs_list = []


    for job in job_listings:
        job_info = {}
        post = job.find_element(By.CLASS_NAME, 'job-list-item__content')
        innerPost = post.find_element(By.CLASS_NAME, 'job-tile__header.job-tile__header--job-info-tags')
        title = innerPost.find_element(By.CSS_SELECTOR, 'span.job-tile__title').text
        
        link = job.find_element(By.CSS_SELECTOR, 'a.job-list-item__link')
        link = link.get_attribute('href')
        

        element = innerPost.find_element(By.CLASS_NAME, 'job-list-item__job-info-value')
        
        try:
            jobType = element.find_element(By.CSS_SELECTOR, 'span[data-bind="text: workplaceTypeName"]').text
        except Exception as ex:
            jobType = None

        location = element.find_element(By.CSS_SELECTOR, 'span[data-bind="html: primaryLocation"]').text
        
        
        elements = innerPost.find_elements(By.CLASS_NAME, 'job-list-item__job-info-value')
        date = elements[1].text
        
        
        

        job_info['Company'] = 'Anixter'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = None
        job_info['Category'] = None
        job_info['Job Type'] = jobType

        

        

        
        jobs_list.append(job_info)

        


    print('scraping anixter')

    # Close the browser
    driver.quit()
    return jobs_list
