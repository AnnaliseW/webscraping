
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def scrape_aarete():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage


    driver.get('https://www.aarete.com/join-our-team/open-positions/')
    jobs_list = []
    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    driver.switch_to.frame(0)  # Or you can use the iframe name if available

    job_listings = []
    # Now you are inside the iframe, you can locate and interact with its elements

    job_listings = driver.find_elements(By.CLASS_NAME, 'jv-job-list')

    for job in job_listings:
        
        category_element = ''
        category_element = job.find_element(By.XPATH, './preceding-sibling::h3[@class="h2"][1]').text
        

        eachPost = job.find_elements(By.TAG_NAME, 'tr')
        for post in eachPost:
            job_info = {}
            title = post.find_element(By.CLASS_NAME, 'jv-job-list-name')
            link = post.find_element(By.TAG_NAME, 'a').get_attribute('href')
            title = title.text

            location = post.find_element(By.CLASS_NAME, 'jv-job-list-location').text
            

            job_info['Company'] = 'Aarete'
            job_info['Job Title'] = title
            job_info['Job Link'] = link
            job_info['Location'] = location
            job_info['Date Posted'] = None
            job_info['ID'] = None
            job_info['Category'] = category_element
            job_info['Job Type'] = None

            
            jobs_list.append(job_info)

    tech_jobs = []
    for job in jobs_list:
        if job['Category'] == 'Operations':
            tech_jobs.append(job)
            










    print('scraping Aarete')




    # Close the browser
    driver.quit()
    return tech_jobs