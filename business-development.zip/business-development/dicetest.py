from requests_html import HTMLSession
from lxml_html_clean import Cleaner


s = HTMLSession()

r = s.get('https://www.dice.com/jobs?q=tech&location=Chicago,%20IL,%20USA&latitude=41.8781136&longitude=-87.6297982&countryCode=US&locationPrecision=City&radius=30&radiusUnit=mi&page=1&pageSize=20&language=en&eid=0345')

sel = '.ng-star-inserted.job-row'

jobs = r.html.find(sel)
print(jobs)