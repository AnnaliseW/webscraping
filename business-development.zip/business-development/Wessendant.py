from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_essendant():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://recruiting2.ultipro.com/UNI1047USINC/JobBoard/f7b2df3b-1c58-45a0-8932-ca9f286a1601/?q=&o=postedDateDesc')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found


    
    # Get the dynamic content
    job_listings = driver.find_elements(By.CLASS_NAME, 'opportunity')


    jobs_list = []



    for job in job_listings:
        job_info = {}
        title = job.find_element(By.CSS_SELECTOR, 'div.col-lg-20.col-md-19.col-sm-18.col-xs-18 a')
        link = title.get_attribute('href')

        title = title.text
        

        date = job.find_element(By.CSS_SELECTOR, 'div.col-lg-4.col-md-5.col-sm-6.col-xs-6.text-right h3')
        date = date.find_element(By.CSS_SELECTOR, 'small').text
        

        category_element = job.find_element(By.CSS_SELECTOR, 'span.label-with-icon[data-automation="job-category"] span[data-bind="text: JobCategoryName()"]')
        category = category_element.text
        

        id_element = job.find_element(By.CSS_SELECTOR, 'div.col-sm-18.col-xs-16.mb-1 span.label-with-icon span[data-bind="text: RequisitionNumber()"]')
        id = id_element.text
        

        jobType = job.find_element(By.CSS_SELECTOR, 'span.label-with-icon span[data-bind="text: FullTimeText"][data-automation="job-hours"]').text
        

        location = job.find_element(By.CSS_SELECTOR, 'candidate-physical-location').text.strip()
        split = location.split("\n")
        location = split[4]
        
        job_info['Company'] = 'Essendant'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = id
        job_info['Category'] = category
        job_info['Job Type'] = jobType
        


        jobs_list.append(job_info)


        


    print('scraping essendant')
        


    # Close the browser
    driver.quit()
    return jobs_list
