from datetime import datetime 
import json
import WTace
import WTallstate
import WTbancoPopular
import WTcheckfollete
import WTcheckkemper
import Wcheckmetrea
import WcheckoldWarIndustries
import WTdWFinePack
import WTelca
import WTford
import WTgrainger
import WgriffithFood
import WTgroupon
import WTHCSC
import WThollister
import WTisaca
import WlibraSolutions
import Wmarketron
import Wnorthshore
import WTrandMcnally
import WusFoods
import WTcovetrus
import WcrateAndBarrel
import Wessendant
import WTfirstGroup
import WgenuineAutoParts
import WThartford
import WITW
import WsevenEleven
import WTtrex
import WtransformHolding
import WTtropicana
import WsheddAquarium
import WTreyesHolding
import WreynoldsConsumerProducts
import Wpetrichor
import WpatientPoint
import WmerchantsFleetManagement
import WTWashingtonPost
import WTverizon
import WcheckcolletteGroup
import WTelkay
import WTbosch
import WTculliganWater
import WFHLBankChicago
import WgreenThumb
import WTpanduit
import WbankTexas
import Wverano
import WWalgreens
import WTcheckwhirlpool
import WlawsonProducts
import Wlowes
import WTamcor
import WTnorthwesternMedicine
import WTnielsen
import WTanixter
import WcheckbylineBank
import Wama
import WTecho
import Wmedline
import Whyatt
import WhugoBoss
import Wunivar
import WvikingCloud
import WloopCapital
import WTaarete
import WfleishmanHillard
import time


#have to delete all output in each class of dictionaries 

def main():
    start_time = time.time() 
    
    # Call the scraping functions from other scripts
    aarete_jobs = WTaarete.scrape_aarete()
    ace_jobs = WTace.scrape_ace()
    allstate_jobs = WTallstate.scrape_allstate()
    ama_jobs = Wama.scrape_ama()
    amcor_jobs = WTamcor.scrape_amcor()
    anixter_jobs = WTanixter.scrape_anixter()
    bancoPopular_jobs = WTbancoPopular.scrape_bancoPopular()
    bosch_jobs = WTbosch.scrape_bosch()
    coveturs_jobs = WTcovetrus.scrape_covetrus()
    crateAndBarrel_jobs = WcrateAndBarrel.scrape_crateAndBarrel()
    culliganWater_jobs = WTculliganWater.scrape_culliganWater()
    dWFinePack_jobs = WTdWFinePack.scrape_dWFinePack()
    echo_jobs = WTecho.scrape_echo()
    elca_jobs = WTelca.scrape_elca()
    elkay_jobs = WTelkay.scrape_elkay()
    essendant_jobs = Wessendant.scrape_essendant()
    FHLBankChicago_jobs = WFHLBankChicago.scrape_FHLBankChicago()
    firstGroup_jobs = WTfirstGroup.scrape_firstGroup()
    fleishmanHillard_jobs = WfleishmanHillard.scrape_FH()
    FORD_jobs = WTford.scrape_FORD()
    genuineAutoParts_jobs = WgenuineAutoParts.scrape_genuineAutoParts()
    grainger_jobs = WTgrainger.scrape_grainger()
    greenThumb_jobs = WgreenThumb.scrape_greenThumb()
    griffithFood_jobs = WgriffithFood.scrape_griffithFood()
    groupon_jobs = WTgroupon.scrape_groupon()
    hartford_jobs = WThartford.scrape_hartford()
    HCSC_jobs = WTHCSC.scrape_HCSC()
    hollister_jobs = WThollister.scrape_hollister()
    hugoBoss_jobs = WhugoBoss.scrape_hugoBoss()
    hyatt_jobs = Whyatt.scrape_hyatt()
    ISACA_jobs = WTisaca.scrape_isaca()
    ITW_jobs = WITW.scrape_ITW()
    lawsonProducts_jobs = WlawsonProducts.scrape_lawsonProducts()
    libraSolutions_jobs = WlibraSolutions.scrape_libraSolutions()
    loopCapital_jobs = WloopCapital.scrape_loopCapital()
    lowes_jobs = Wlowes.scrape_lowes()
    marketron_jobs = Wmarketron.scrape_marketron()
    medline_jobs = Wmedline.scrape_medline()
    merchantsFleetManagement_jobs = WmerchantsFleetManagement.scrape_merchantsFleetManagement()
    nielsen_jobs = WTnielsen.scrape_nielsen()
    northshore_jobs = Wnorthshore.scrape_northshore()
    northwesternMedicine_jobs = WTnorthwesternMedicine.scrape_northwesternMedicine()
    panduit_jobs = WTpanduit.scrape_panduit()
    patientPortal_jobs = WpatientPoint.scrape_patientPortal()
    petrichor_jobs = Wpetrichor.scrape_petrichor()
    randMcnally_jobs = WTrandMcnally.scrape_randMcnally()
    reyesHolding_jobs = WTreyesHolding.scrape_reyesHolding()
    reynoldsConsumerProducts_jobs = WreynoldsConsumerProducts.scrape_reynoldsConsumerProducts()
    sevenEleven_jobs = WsevenEleven.scrape_sevenEleven()
    sheddAquarium_jobs = WsheddAquarium.scrape_sheddAquarium()
    stateBankTexas_jobs = WbankTexas.scrape_bankTexas()
    transformHolding_jobs = WtransformHolding.scrape_transformHolding()
    trex_jobs = WTtrex.scrape_trex()
    tropicana_jobs = WTtropicana.scrape_tropicana()
    univar_jobs = Wunivar.scrape_univar()
    usFoods_jobs = WusFoods.scrape_usFoods()
    verizon_jobs = WTverizon.scrape_verizon()
    verano_jobs = Wverano.scrape_verano()
    vikingCloud_jobs = WvikingCloud.scrape_vikingCloud()
    walgreens_jobs = WWalgreens.scrape_walgreens()
    washingtonPost_jobs = WTWashingtonPost.scrape_theWashingtonPost()
    Z_bylineBanks_jobs = WcheckbylineBank.scrape_bylineBank()
    Z_colletteGroup_jobs = WcheckcolletteGroup.scrape_colletteGroup()
    Z_follete_jobs = WTcheckfollete.scrape_follete()
    Z_kemper_jobs = WTcheckkemper.scrape_kemper()
    Z_metrea_jobs = Wcheckmetrea.scrape_metrea()
    Z_oldWarIndustries_jobs = WcheckoldWarIndustries.scrape_oldWarIndustries()
    Z_whirlpool_jobs = WTcheckwhirlpool.scrape_whirlpool()

    # Combine the lists
    all_jobs = (aarete_jobs + ace_jobs + allstate_jobs + ama_jobs + amcor_jobs + anixter_jobs + bancoPopular_jobs + 
                bosch_jobs + coveturs_jobs + 
                crateAndBarrel_jobs + culliganWater_jobs + dWFinePack_jobs + 
                echo_jobs + elca_jobs + elkay_jobs + essendant_jobs + FHLBankChicago_jobs + firstGroup_jobs + fleishmanHillard_jobs + FORD_jobs +
                genuineAutoParts_jobs + grainger_jobs + greenThumb_jobs + griffithFood_jobs + groupon_jobs + 
                hartford_jobs + HCSC_jobs + hollister_jobs + hugoBoss_jobs + hyatt_jobs + ISACA_jobs + ITW_jobs + lawsonProducts_jobs + 
                libraSolutions_jobs + loopCapital_jobs + lowes_jobs + marketron_jobs + medline_jobs + merchantsFleetManagement_jobs + 
                nielsen_jobs + northshore_jobs + northwesternMedicine_jobs + 
                panduit_jobs + patientPortal_jobs + petrichor_jobs + randMcnally_jobs + reyesHolding_jobs + 
                reynoldsConsumerProducts_jobs + sevenEleven_jobs + sheddAquarium_jobs + stateBankTexas_jobs + transformHolding_jobs + trex_jobs + tropicana_jobs + 
                univar_jobs + usFoods_jobs + verizon_jobs + verano_jobs + vikingCloud_jobs + walgreens_jobs + washingtonPost_jobs + Z_bylineBanks_jobs +
                Z_colletteGroup_jobs + Z_follete_jobs + Z_kemper_jobs + Z_metrea_jobs + Z_oldWarIndustries_jobs + Z_whirlpool_jobs)

    current_date = datetime.now().strftime("%Y-%m-%d")
    file_name = f'all_jobs_{current_date}.json'
    # Write the combined list to a JSON file
    with open(file_name, 'w') as json_file:
        json.dump(all_jobs, json_file, indent=4)

    with open('all_jobs.json', 'w') as json_file:
        json.dump(all_jobs, json_file, indent=4)

    end_time = time.time()  
    elapsed_time = end_time - start_time  
    minutes = elapsed_time / 60
    print(f"Time taken: {minutes} minutes")

if __name__ == "__main__":
    main()
