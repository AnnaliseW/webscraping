from requests_html import HTMLSession

def scrape_ace():
    s = HTMLSession()
    r = s.get('https://careers.acehardware.com/job-search/?category=&career_area=Corporate&keyword=IT&radius=10&spage=1', verify=False)

    sel = '.search--item'
    jobs = r.html.find(sel)

    jobs_list = []

    for element in jobs:
        job_info = {}

        # Find the <p> element with class 'req' within the current element
        req_element = element.find('p.req')
        reqID = req_element[0].text
        location = req_element[1].text

        link_element = element.find('a', first=True)
        link = 'https://careers.acehardware.com/' + link_element.attrs['href']
        job_title = link_element.text

        category_div = element.find('div.col-12.col-md-4.mb1.mb0--md', first=True)
        category_p = category_div.find('p', first=True)
        category = category_p.text.strip()  # Stripping extra spaces

        job_info = {
            'Company': 'Ace Hardware',
            'Job Title': job_title,
            'Job Link': link,
            'Location': location,
            'Date Posted': None,
            'ID': reqID,
            'Category': category,
            'Job Type': None
        }
        
        jobs_list.append(job_info)

    print('scraping Ace')

    


    return jobs_list

