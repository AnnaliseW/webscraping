from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException

def scrape_hyatt():
    # Setup chrome options
    chrome_options = Options()

    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://careers.hyatt.com/en-US/careers/search?searchable=%5B%7B%22id%22%3A110000%2C%22text%22%3A%22Technology%22%2C%22portal%22%3A%5B%5D%2C%22filterId%22%3A%22JOB_FIELD%22%7D%5D')

    # Set implicit wait
    driver.implicitly_wait(15)  # Wait up to 10 seconds for elements to be found

    wait = WebDriverWait(driver, 15)

    jobs = driver.find_elements(By.XPATH, '/html/body/ats-app/main/customer-init/app-page-layout/section/hyatt-search/hyatt-search-base/section/div/div[3]/hyatt-search-results/table/tr/div')


    jobs_list = []

    for job in jobs:
        try:
            title = job.find_element(By.TAG_NAME, 'a').text
            job_info = {}
            find = job.find_element(By.CSS_SELECTOR, 'div.col-lg-4')
            link = find.find_element(By.TAG_NAME, 'a').get_attribute('href')
            test = job.find_element(By.CSS_SELECTOR, 'div.row')
            elements = test.find_elements(By.TAG_NAME, 'span')
            category = elements[1].text
            location = elements[2].text
            date = elements[3].text

            job_info['Company'] = 'Hyatt'
            job_info['Job Title'] = title
            job_info['Job Link'] = link
            job_info['Location'] = location
            job_info['Date Posted'] = date
            job_info['ID'] = None
            job_info['Category'] = category
            job_info['Job Type'] = None

            jobs_list.append(job_info)
        except:
            print('fail')

        
    print('scraping hyatt')
    

    # Close the browser
    driver.quit()
    return jobs_list

