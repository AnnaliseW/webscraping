from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_ITW():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://jobs.itw.com/search-jobs')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    # Get the dynamic content
    job_listings = driver.find_elements(By.CSS_SELECTOR, 'li')


    jobs_list = []


    for job in job_listings[:15]:
        job_info = {}
        element = job.find_element(By.CSS_SELECTOR, 'a')
        link = element.get_attribute('href')

        title = element.find_element(By.CSS_SELECTOR, 'h2').text
    

        location = job.find_element(By.CSS_SELECTOR, 'span.job-location.expandable')
        location = location.text


        date = job.find_element(By.CSS_SELECTOR, 'span.job-date-posted')
        date = date.text
    

        
        
        job_info['Company'] = 'ITW'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = None
        job_info['Category'] = None
        job_info['Job Type'] = None

        jobs_list.append(job_info)


        
        

    print('scraping ITW')
    


        

    # Close the browser
    driver.quit()
    return jobs_list

