from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def scrape_FORD():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://efds.fa.em5.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1/requisitions?lastSelectedFacet=CATEGORIES&mode=location&selectedCategoriesFacet=300002487990164%3B300002487961196')

    # Set implicit wait
    driver.implicitly_wait(5)  # Wait up to 10 seconds for elements to be found


    # Get the dynamic content
    job_listings = driver.find_elements(By.CLASS_NAME, 'job-tile__header.job-tile__header--job-info-tags')



    jobs_list = []


    for job in job_listings:
        job_info = {}

        title = job.find_element(By.CLASS_NAME, 'job-tile__title').text
        

        link = driver.execute_script(
        "return document.querySelector('.job-list-item__link').getAttribute('href');")


        subheader = job.find_element(By.CLASS_NAME, 'job-tile__subheader')
        element = subheader.find_element(By.CLASS_NAME, 'job-list-item__job-info-value')
        find = element.find_elements(By.CSS_SELECTOR, 'span')
        location = find[0].text
        

        if len(find) == 2:
            jobType = find[1].text
        else:
            jobType = None

        
        date_element = subheader.find_elements(By.CLASS_NAME, 'job-list-item__job-info-value-container')
        date = date_element[1].text
        

        job_info['Company'] = 'FORD'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = None
        job_info['Category'] = None
        job_info['Job Type'] = jobType


        jobs_list.append(job_info)
        
    print('scraping FORD')

  
    # Close the browser
    driver.quit()
    return jobs_list
