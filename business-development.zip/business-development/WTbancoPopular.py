import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin



def scrape_bancoPopular():

    urlIT = 'https://jobs.popular.com/go/Innovation%2C-Technology%2C-&-Operations/9114500/'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    }
    r = requests.get(urlIT, headers=headers)
    soup = BeautifulSoup(r.content, 'html.parser')

    jobs_list = []  # List to store all job 

    tables = soup.find_all('table')
    for table in tables:
        job_info = {}
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')
        for row in rows[:-2]:
            job_data = {}
            cells = row.find_all('td')

        # Check if the row contains a link, indicating a job posting
            if cells[0].find('a'):
                link = cells[0].find('a')
                job_title = link.get_text(strip=True)
        
                job_link = urljoin('https://jobs.popular.com/', link['href'])
                
        
                location_element = cells[0].find('span', class_='jobLocation')
                location = location_element.get_text(strip=True) 
            

                remoteHybrid_element = cells[0].find('span', class_='jobShifttype')
                remoteHybrid = remoteHybrid_element.get_text(strip=True) 
                

                date_element = cells[0].find('span', class_='jobDate')
                date = date_element.get_text(strip=True)
                
                
                job_info = {
                    'Company': 'Banco Popular',
                    'Job Title': job_title,
                    'Job Link': job_link,
                    'Location': location,
                    'Date Posted': date,
                    'ID': None,
                    'Category': None,
                    'Job Type': None

                }
                
                jobs_list.append(job_info)



    urlData = 'https://jobs.popular.com/go/Data%2C-Analytics%2C-Project-Management-&-Process-Efficiency/9113600/'

    r = requests.get(urlData, headers=headers)
    soup = BeautifulSoup(r.content, 'html.parser')



    tables = soup.find_all('table')
    for table in tables:
        job_info = {}
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')
        for row in rows[:-2]:
            job_data = {}
            cells = row.find_all('td')

        # Check if the row contains a link, indicating a job posting
            if cells[0].find('a'):
                link = cells[0].find('a')
                job_title = link.get_text(strip=True)
        
                job_link = urljoin('https://jobs.popular.com/', link['href'])
                
        
                location_element = cells[0].find('span', class_='jobLocation')
                location = location_element.get_text(strip=True) 
            

                remoteHybrid_element = cells[0].find('span', class_='jobShifttype')
                remoteHybrid = remoteHybrid_element.get_text(strip=True) 
                

                date_element = cells[0].find('span', class_='jobDate')
                date = date_element.get_text(strip=True)
                
                
                job_info = {
                    'Company': 'Banco Popular',
                    'Job Title': job_title,
                    'Job Link': job_link,
                    'Location': location,
                    'Date Posted': date,
                    'ID': None,
                    'Category': None,
                    'Job Type': None

                }
                
                if job_info not in jobs_list:
                    jobs_list.append(job_info)




    return jobs_list




        

        




