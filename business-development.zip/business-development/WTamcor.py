from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_amcor():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://www.amcor.com/careers/job-search?keyword=&category=Information+Technology')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    jobs_list = []

    job_listings = driver.find_elements(By.CSS_SELECTOR, 'div.sc-f627fa1b-0.iKIJxI')



    for job in job_listings:
        job_info = {}
        
        title = job.find_element(By.CSS_SELECTOR, 'div.sc-e5f86823-0.kbrrvr').text
        

        link = job.find_element(By.TAG_NAME, 'a').get_attribute('href')
        


        elements = job.find_element(By.CSS_SELECTOR, 'p.sc-4dd6b832-0.sc-f627fa1b-8.beCgXh.hoEfiu').text
        splits = elements.split('-')
        date = splits[0].strip()
        id = splits[1].strip()


        category = job.find_element(By.CSS_SELECTOR, 'div[class^="sc-4b856a84-0"]').text

        
        
        

        location = job.find_elements(By.CSS_SELECTOR, 'div.sc-f627fa1b-3.jLazyk')
        locationCollection = ""
        
        for i in location:
            locationCollection = locationCollection + i.text

        


        test = job.find_element(By.CSS_SELECTOR, 'div.sc-f627fa1b-4.dVMoWo').text
        findType = test.split("-")
        jobType = findType[-1].strip()
        if 'Show more locations' in jobType:
            jobType = jobType.replace('+ Show more locations\n', '')
        findType = jobType.split('\n')
        jobType = findType[1]

        job_info['Company'] = 'Amcor'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Date Posted'] = date
        job_info['ID'] = id
        job_info['Category'] = category
        job_info['Job Type'] = jobType

        

        jobs_list.append(job_info)
   

        


    print('scraping amcor')


    # Close the browser
    driver.quit()

    return jobs_list