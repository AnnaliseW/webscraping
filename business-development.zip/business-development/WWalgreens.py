from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager


def scrape_walgreens():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://jobs.walgreens.com/en/search-jobs')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.CSS_SELECTOR, "li.branded-list__list-item")


    jobs_list = []

    for job in jobs:
        job_info = {}

        title = job.find_element(By.CSS_SELECTOR, 'h2.headline.headline--xs').text
        location = job.find_element(By.CSS_SELECTOR, 'span.job-location').text

        link = job.find_element(By.TAG_NAME, 'a').get_attribute('href')
        

        job_info = {
            'Company': 'Walgreens',
            'Job Title': title,
            'Job Link': link,
            'Location': location,
            'Date Posted': None,
            'ID': None,
            'Category': None,
            'Job Type': None
        }

        jobs_list.append(job_info)

    print('scraping Walgreens')
    
    # Close the browser
    driver.quit()
    return jobs_list