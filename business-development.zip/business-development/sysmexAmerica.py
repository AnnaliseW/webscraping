from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Setup chrome options
chrome_options = Options()
chrome_options.add_argument("--headless")  # Ensure GUI is off
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")

# Set up the Chrome webdriver service
webdriver_service = Service(ChromeDriverManager().install())

# Start the browser
driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

# Open the webpage
driver.get('https://careers-sysmex.icims.com/jobs/search?ss=1')

# Set implicit wait
driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found





job_listings = driver.find_elements(By.CLASS_NAME, 'row')
print(job_listings)

for job in job_listings:
    job_info = {}
    
#     title = job.find_element(By.TAG_NAME, 'h3')
#     link = job.find_element(By.TAG_NAME, 'a')
#     link = link.get_attribute('href')
#     title = title.text
    

#     jobType = job.find_element(By.CSS_SELECTOR, 'span.job-jobtype').text
    

#     address= job.find_element(By.CSS_SELECTOR, 'span.job-address').text
    
#     location = job.find_element(By.CSS_SELECTOR, 'span.job-location').text
#     location = location.replace('Locations: ', '')
    

#     date = job.find_element(By.CSS_SELECTOR, 'span.job-date-posted').text
    

#     job_info['Company'] = 'Crate and Barrel'
#     job_info['Job Title'] = title
#     job_info['Job Link'] = link
#     job_info['Job Type'] = jobType
#     job_info['Address'] = address
#     job_info['Location'] = location
#     job_info['Date Posted'] = date

    

    
#     jobs_list.append(job_info)

    


# # Print the list of dictionaries
# for job in jobs_list:
#     print(job)
#     print()
    


# Close the browser
driver.quit()

