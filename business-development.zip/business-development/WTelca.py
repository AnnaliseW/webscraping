from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_elca():

    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://recruiting.paylocity.com/recruiting/jobs/All/8a4f374c-1d77-4459-b1e2-64af63073eee/Evangelical-Lutheran-Church-in-America?location=All%20Locations&department=Operations%20-%20Information%20Technology')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    # Get the dynamic content
    job_listings = driver.find_elements(By.CLASS_NAME, 'row.job-listing-job-item')

    jobs_list = []

    for job in job_listings:
        job_info = {}

        title = job.find_element(By.CSS_SELECTOR, 'span.job-item-title').text


        a_element = driver.find_element(By.CSS_SELECTOR, "span a")

        # Extract the href attribute
        job_link = a_element.get_attribute("href")
        

        date_element = job.find_element(By.XPATH, ".//span[2]")
        date = date_element.text
        date = date.replace('-', '')
        


        department_elements = job.find_elements(By.CSS_SELECTOR, 'span.job-item-normal')
        
        if len(department_elements) > 1:
            department = department_elements[0].text
            
            location = department_elements[1].text
        
        else:
            location = department_elements[0].text 
            
        
        job_info = {
                    'Company': 'ELCA',
                    'Job Title': title,
                    'Job Link': job_link,
                    'Location': location,
                    'Date Posted': date,
                    'ID': None,
                    'Category': None,
                    'Job Type': None
                
                }
        if department:
            job_info['Department'] = department
                
        jobs_list.append(job_info)

    print('scraping ELCA')

 
        



    driver.quit()
    return jobs_list
