from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_usFoods():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://careers.usfoods.com/us/en/search-results')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found


    
    # Get the dynamic content
    job_listings = driver.find_elements(By.CLASS_NAME, 'jobs-list-item')


    jobs_list = []


    for job in job_listings:
        job_info = {}

        title = job.find_element(By.CSS_SELECTOR, 'div.job-title').text

        a_element = driver.find_element(By.CSS_SELECTOR, "span a")

        # Extract the href attribute
        job_link = a_element.get_attribute("href")
        
        

        location = job.find_element(By.CSS_SELECTOR, 'span.job-location').text
        location = location.replace("Location\n", "")

        category = job.find_element(By.CSS_SELECTOR, 'span.job-category').text
        category = category.replace("Category\n", '')

        jobType = job.find_element(By.CSS_SELECTOR, 'span.au-target.type').text
        jobType = jobType.replace("Job Type\n", "")

        id = job.find_element(By.CSS_SELECTOR, 'span.au-target.jobId').text
        id = id.replace("Job Id\n", '')

        date = job.find_element(By.CSS_SELECTOR, "span.job-postdate").text
        date = date.replace("Posted Date\n", '')

        job_info['Company'] = 'US Foods'
        job_info['Job Title'] = title
        job_info['Job Link'] = job_link
        job_info['Location'] = location
        job_info['Date Posted'] = date
        job_info['ID'] = id
        job_info['Category'] = category
        job_info['Job Type'] = jobType
    
    

        jobs_list.append(job_info)

    print('scraping US Foods')
    


    # Close the browser
    driver.quit()
    return jobs_list