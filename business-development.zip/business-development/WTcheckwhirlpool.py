from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin

def scrape_whirlpool():

    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://jobs.whirlpool.com/careers?department=Technology%20%2820000012%29&pid=34382032809&domain=whirlpool.com&sort_by=relevance&triggerGoButton=false')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.CSS_SELECTOR, "div.card.position-card.pointer")


    jobs_list = []

    for job in jobs:
        job_info = {}

        title = job.find_element(By.CLASS_NAME, 'position-title.line-clamp.line-clamp-2').text
        

        location_element = job.find_element(By.CSS_SELECTOR, '.position-location')
        location_icon = location_element.find_element(By.CLASS_NAME, 'fa-map-marker-alt')
        location = location_element.text.replace(location_icon.text, '').strip()

        # Extract department
        department = job.find_element(By.CLASS_NAME, 'position-priority-container').text


    #NO LINK FOR NOW

        if title and location and department:
            job_info['Company'] = 'Whirlpool'
            job_info['Job Title'] = title
            job_info['Job Link'] = None
            job_info['Location'] = location
            job_info['Date Posted'] = None
            job_info['ID'] = None
            job_info['Category'] = department
            job_info['Job Type'] = None

            jobs_list.append(job_info)


    print('scraping whirlpool')


    driver.quit()
    return jobs_list
