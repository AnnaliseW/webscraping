from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_verizon():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://mycareer.verizon.com/jobs/?search=&team=Technology&pagesize=20#results')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    # Get the dynamic content
    job_listings = driver.find_elements(By.CSS_SELECTOR, 'div.card.card-job')



    jobs_list = []


    for job in job_listings:
        job_info = {}

        title = job.find_element(By.CSS_SELECTOR, 'a.stretched-link.js-view-job')
        link = title.get_attribute('href')
        title = title.text
        

        ul_element = job.find_element(By.XPATH, ".//ul[contains(@class, 'list-inline job-')]")
        li_elements = ul_element.find_elements(By.TAG_NAME, 'li')

        location = li_elements[0].text if len(li_elements) > 0 else None
        department = li_elements[1].text if len(li_elements) > 1 else None

        
        job_info['Company'] = 'Verizon'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = None
        job_info['ID'] = None
        job_info['Category'] = department
        job_info['Job Type'] = None

        jobs_list.append(job_info)

    print('scraping Verizon')
    




    # Close the browser
    driver.quit()
    return jobs_list
