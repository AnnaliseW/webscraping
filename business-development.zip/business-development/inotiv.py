from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
# Set up WebDriver
driver = webdriver.Chrome()  # You can change this to Firefox or any other supported browser

# Load webpage
driver.get("https://careers-inotiv.icims.com/")

# Find and switch to iframes
iframes = driver.find_elements(By.TAG_NAME, 'iframe')


for iframe in iframes:
    driver.switch_to.frame(iframe)
    
   
    
    # After processing the content of this iframe, switch back to the default content
    driver.switch_to.default_content()

# Close the WebDriver
driver.quit()
