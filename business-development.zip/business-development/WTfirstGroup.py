from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin


def scrape_firstGroup():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://careers.firstgroup.co.uk/jobs/search?page=1&dropdown_field_3_uids%5B%5D=9d77f3a74549456870a0779daf521d4b&query=')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.TAG_NAME, 'tr')


    jobs_list = []

    for job in jobs[1:]:
        job_info = {}

        title = job.find_element(By.CLASS_NAME, 'job-search-results-title')
        title = title.text
        

        link = job.find_element(By.CSS_SELECTOR, 'td.job-search-results-title a')
        link = link.get_attribute('href')


        jobType = job.find_element(By.CLASS_NAME, 'job-search-results-employment-type')
        jobType = jobType.text
        

        location = job.find_element(By.CLASS_NAME, 'job-search-results-location')
        location = location.text
        

        

        category = job.find_element(By.CLASS_NAME, 'job-search-results-dropdown_field_3')
        category = category.text


        job_info['Company'] = 'First Group'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = None
        job_info['ID'] = None
        job_info['Category'] = category
        job_info['Job Type'] = jobType
        



        jobs_list.append(job_info)


    print('scraping First Group')


    driver.quit()
    return jobs_list

