from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_echo():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://www.echo.com/company/careers/open-positions/?department=technology')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found



    # Get the dynamic content
    job_listings = driver.find_elements(By.CSS_SELECTOR, 'div.col-md-6.col-lg-6.archive-view.archive-card.archive-job')


    jobs_list = []


    for job in job_listings:
        job_info = {}

        inner = job.find_element(By.CLASS_NAME, 'archive-element.card-link')
        innerInner = inner.find_element(By.CLASS_NAME, 'archive-body')
        

        title = innerInner.find_element(By.CLASS_NAME, 'post-title')

        title = title.get_attribute('textContent').strip()



        findElements = innerInner.find_element(By.CSS_SELECTOR, 'p.label')
        
        # Retrieve the text using get_attribute('textContent')
        elements = findElements.get_attribute('textContent').strip()
        split = elements.split('|')
        jobType = split[0].strip()


        location = split[1].strip()


        if len(split) == 3:
            category = split[2].strip()
        
        else:
            category = None


        link = inner.find_element(By.TAG_NAME, 'a').get_attribute('href')


        job_info['Company'] = 'Echo Global Logistics'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = None
        job_info['ID'] = None
        job_info['Category'] = category
        job_info['Job Type'] = jobType


        
        jobs_list.append(job_info)

        


    print('scraping echo')



    # Close the browser
    driver.quit()
    return jobs_list