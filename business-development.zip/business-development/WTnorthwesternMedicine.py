from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def scrape_northwesternMedicine():

    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://jobs.nm.org/search-jobs?acm=70331')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 2 seconds for elements to be found
    # Get the job listings
    job_listings = driver.find_elements(By.XPATH, '//*[@id="search-results-list"]/ul/li')

    jobs_list = []

    for job in job_listings[0:24]:
        job_info = {}
        title = job.find_element(By.TAG_NAME, 'h2').text


        link = job.find_element(By.TAG_NAME, 'a').get_attribute('href')


        location = job.find_element(By.CSS_SELECTOR, 'span.job-location').text

        split = job.find_elements(By.CSS_SELECTOR, 'span')
        id = split[1].text
        id = id.replace('Job ', '')


        job_info['Company'] = 'Northwestern Medicine'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = None
        job_info['ID'] = id
        job_info['Category'] = None
        job_info['Job Type'] = None

        jobs_list.append(job_info)


        



    print('scraping northwestern medicine')




    # Close the browser
    driver.quit()
    return jobs_list