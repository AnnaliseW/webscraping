from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_libraSolutions():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://www.librasolutionsgroup.com/careers/')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found


    # Get the dynamic content
    job_listings = driver.find_elements(By.CLASS_NAME, 'resumator-job')


    jobs_list = []


    for job in job_listings:
        job_info = {}
        department = ''

        title = job.find_element(By.CSS_SELECTOR, 'div.resumator-job-title.resumator-jobs-text').text


        location_department = job.find_element(By.CSS_SELECTOR, 'div.resumator-job-info.resumator-jobs-text').text
        
        if 'Department' in location_department:
            split = location_department.split('Department')
            location = split[0]
            location = location.replace("Location: ", "")
            department = split[1]
            department = department.replace(": ", "")
            
        else:
            location_department = location
            location = location.replace('Location: ', '')
            

        link = job.find_element(By.CSS_SELECTOR, 'div.resumator-job-view-details.resumator-jobs-text a')
        link = link.get_attribute('href')
        
        job_info['Company'] = 'Libra Solutions'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = None
        job_info['ID'] = None
        if department:
            job_info['Category'] = department
        else:
            job_info['Category'] = None

        job_info['Job Type'] = None


        
        jobs_list.append(job_info)



    print('scraping libra solutions')
    

    # Close the browser
    driver.quit()
    return jobs_list