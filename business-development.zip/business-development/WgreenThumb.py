from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager


def scrape_greenThumb():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://boards.greenhouse.io/greenthumbindustries')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found


    jobs_list = []

    job_openings = driver.find_elements(By.CSS_SELECTOR, 'div.opening')



    h4_tags = driver.find_elements(By.XPATH, '//section[@class="child level-1"]/h4')

    for h4_tag in h4_tags:
            # Get department name
            department = h4_tag.text

            # Find job openings associated with this department
            job_openings = h4_tag.find_elements(By.XPATH, './following-sibling::div[@class="opening"]')

            for job in job_openings:
                job_info = {}

                element = job.find_element(By.TAG_NAME, 'a')
                title = element.text
                link = element.get_attribute('href')

                location = job.find_element(By.CSS_SELECTOR, 'span.location').text

                job_info = {
                    'Company': 'Green Thumb Industries',
                    'Job Title': title,
                    'Job Link': link,
                    'Location': location,
                    'Date Posted': None,
                    'ID': None,
                    'Category': department,
                    'Job Type': None
                }

                jobs_list.append(job_info)

  

    print('scraping Green Thumb')
    # Close the browser
    driver.quit()
    return jobs_list