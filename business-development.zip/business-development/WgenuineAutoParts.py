from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from urllib.parse import urljoin
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def scrape_genuineAutoParts():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://jobs.genpt.com/search-jobs')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    job_listings = driver.find_elements(By.XPATH, '//*[@id="search-filters"]/div/div[1]/section[4]/ul/li[17]/label')


    jobs_list = []



    for job in job_listings[1:]:
        job_info = {}

        link = job.find_element(By.CSS_SELECTOR, 'a.sr-job-link')
        link = link.get_attribute('href')
        

        title = job.find_element(By.CSS_SELECTOR, 'h2.sr-job-link__hl')
        title = title.text
        

        location = job.find_element(By.CSS_SELECTOR, 'span.job-info.job-location')
        location = location.text


        jobType = job.find_element(By.CSS_SELECTOR, 'span.job-info.job-industry')
        jobType = jobType.text
        

        job_info['Company'] = 'Genuine Auto Parts'
        job_info['Job Title'] = title
        job_info['Job Link'] = link
        job_info['Location'] = location
        job_info['Date Posted'] = None
        job_info['ID'] = None
        job_info['Category'] = None
        job_info['Job Type'] = jobType


        


        jobs_list.append(job_info)


        


    print('scraping Genuine Auto Parts')
        


    # Close the browser
    driver.quit()
    return jobs_list
