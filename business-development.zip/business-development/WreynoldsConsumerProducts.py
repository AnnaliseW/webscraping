from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

def scrape_reynoldsConsumerProducts():
    # Setup chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Ensure GUI is off
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # Set up the Chrome webdriver service
    webdriver_service = Service(ChromeDriverManager().install())

    # Start the browser
    driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

    # Open the webpage
    driver.get('https://careers.reynoldsconsumerproducts.com/en-US/page/corporate')

    # Set implicit wait
    driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

    # Get the dynamic content
    jobs = driver.find_elements(By.CSS_SELECTOR, "tr.job-result")


    jobs_list = []

    for job in jobs:
        job_info = {}
        title = job.find_element(By.CSS_SELECTOR, 'a.primary-text-color.job-result-title')
        link = title.get_attribute('href')
        title = title.text
        
        

        location = job.find_element(By.CSS_SELECTOR, 'div.job-location-line').text
       

        date = job.find_element(By.CLASS_NAME, 'col-md-2.job-result-date-posted-cell').text
     


        job_info = {
            'Company': 'Reynolds Consumer Products',
            'Job Title': title,
            'Job Link': link,
            'Location': location,
            'Date Posted': date,
            'ID': None,
            'Category': None,
            'Job Type': None

        }

        jobs_list.append(job_info)

    print('scraping Reynolds Consumer')
    

    # Close the browser
    driver.quit()
    return jobs_list

