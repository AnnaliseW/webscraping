from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager



# Setup chrome options
chrome_options = Options()
chrome_options.add_argument("--headless")  # Ensure GUI is off
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")

# Set up the Chrome webdriver service
webdriver_service = Service(ChromeDriverManager().install())

# Start the browser
driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

# Open the webpage
driver.get('https://www.zoro.com/careers/disability-hiring/?gclid=88c5c3f8e9571aeb0510a5afbcf34428&gclsrc=3p.ds&msclkid=88c5c3f8e9571aeb0510a5afbcf34428&utm_source=bing&utm_medium=cpc&utm_campaign=ml_all_dyn_main_pmax_Bing%20r3%20pla%20sales&utm_term=www.zoro.com&utm_content=r3%20pla%20sales#grnhse_app')

# Set implicit wait
driver.implicitly_wait(2)  # Wait up to 10 seconds for elements to be found

jobs_list = []

job_openings = driver.find_elements(By.CSS_SELECTOR, 'div.opening')



categories = driver.find_element(By.XPATH, '//*[@id="embedded_job_board_wrapper"]/section')
print(categories)

# Close the browser
driver.quit()
for job in categories:
    print()